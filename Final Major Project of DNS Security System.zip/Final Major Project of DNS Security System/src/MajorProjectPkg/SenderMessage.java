package MajorProjectPkg;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;
import java.security.*;
import java.security.SecureRandom.*;
import java.security.spec.*;
import javax.swing.*;

public class SenderMessage extends JFrame implements ActionListener
{
    JTabbedPane TabbedPane ;
    JButton send;
    JTextArea MessageTextArea;
    JScrollPane MessageScrollPane;
    String finalEncodedString=" ";
    byte str[];
    byte[] digitalSignature;
    String y="";
    String st="";
    ClientDetail ct;

    public SenderMessage(ClientDetail ct)
    {
	super("Transaction");
	this.ct=ct;
	setSize(500,500);
	Container c = getContentPane();
	JPanel panel = new JPanel(new FlowLayout());
	JLabel MessageLabel = new JLabel("Enter the Text: ");
	MessageTextArea = new JTextArea(20,40);
	MessageScrollPane = new JScrollPane(MessageTextArea);
	send= new JButton("Send");
	panel.add(MessageLabel);
	panel.add(MessageScrollPane);
	panel.add(send);
	panel.setVisible(true);         
        send.addActionListener(this);                          
        TabbedPane = new JTabbedPane();
	TabbedPane.addTab("Message",null,panel,"Enter the Message here");
	c.add(TabbedPane);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setVisible(true);
	setResizable(false);
    }
	/*         MESSAGE DIGEST ALOGORITHM          */
    private byte[] content;

    public byte[] digestValue(byte[] in_text1)
    {
	byte[] in_text=in_text1;
	content=in_text;
	MessageDigest mg1=null;
	try
	{
            mg1=MessageDigest.getInstance("SHA1");
	}
	catch (Exception e)
	{
            JOptionPane.showMessageDialog(null, "Exception in DigestValue method \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(e);
	}
        mg1.update(content);
	byte[] digest1=mg1.digest();
	System.out.println("Message Digest:"+digest1);
	return digest1;
    }

    public void keyGenerator()
    {
    	try
    	{
            KeyPairGenerator keygen = KeyPairGenerator.getInstance("DSA","SUN");
             /* cryptographically strong pseudo-random number generator (PRNG) */
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG","SUN");
            keygen.initialize(1024,random);
            KeyPair keypair = keygen.generateKeyPair();
            PrivateKey privatekey = keypair.getPrivate();
            PublicKey publickey = keypair.getPublic();
            FileOutputStream pubkeyfos = new FileOutputStream("public.txt");
            pubkeyfos.write(publickey.getEncoded());
            System.out.println("PublicKey"+publickey.getEncoded());
            pubkeyfos.close();
            FileOutputStream prikeyfos = new FileOutputStream("private.txt");
            prikeyfos.write(privatekey.getEncoded());
            System.out.println("PrivateKey:"+privatekey);            
            prikeyfos.close();
            JOptionPane.showMessageDialog(null, "keys are created","Keys", JOptionPane.INFORMATION_MESSAGE);
	}
        catch(Exception e)
	{
            JOptionPane.showMessageDialog(null, "Exception in Key Generation method \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(e);
	}
    }

    public void SignatureGenerator(String PublicKeyName)
    {
	try
	{
            byte[] MessageDigest;
            String args=PublicKeyName;
            FileInputStream messageDigestFileInput=new FileInputStream(args);
            byte[] in_text=new byte[messageDigestFileInput.available()];
            messageDigestFileInput.read(in_text);
            messageDigestFileInput.close();
            //SHA sha=new SHA(in_text);
            MessageDigest=digestValue(in_text);
            FileInputStream privateKeyFileInput=new FileInputStream("private.txt");
            byte[] enc_priv=new byte[privateKeyFileInput.available()];
            privateKeyFileInput.read(enc_priv);
            privateKeyFileInput.close();
            Signature dsa=Signature.getInstance("SHA1withDSA","SUN");
            PKCS8EncodedKeySpec privKeySpec=new PKCS8EncodedKeySpec(enc_priv);
            KeyFactory keyFactory=KeyFactory.getInstance("DSA","SUN");
            PrivateKey privateKeyVariable=(PrivateKey)keyFactory.generatePrivate(privKeySpec);
            dsa.initSign(privateKeyVariable);
            dsa.update(MessageDigest);
            digitalSignature=dsa.sign();
            System.out.println("Generated Signature :"+digitalSignature);
            FileOutputStream signatureFileOutput = new FileOutputStream("realSign.txt");
            signatureFileOutput.write(digitalSignature);
            signatureFileOutput.close();
            JOptionPane.showMessageDialog(null, "Signature are Generated","Signature", JOptionPane.INFORMATION_MESSAGE);
	}
        catch(Exception e)
	{
            JOptionPane.showMessageDialog(null, "Exception in Digital Signature generation method \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(e);
	}
    }

    public void actionPerformed(ActionEvent e)
    {
	if(e.getSource() == send)
	{
            if (MessageTextArea.getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, "Message Cannot be EMPTY","Alert", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                Hex_Code_Conversion();
		int i;
		int b[]=new int[5000];
		int ArrayofOriginalMessage[]=new int[5000];
		String generatedString=" ";
		char s;
		String OriginalMessage=MessageTextArea.getText();
		System.out.println("Message Entered:"+OriginalMessage);
		int lengthofMessage=OriginalMessage.length();
		System.out.println("StringLength:"+lengthofMessage); 
		System.out.print("HASH-CODE:");
                       //It convert each character of original string into ASCII value and store it in Different Array
		for(i=0;i<lengthofMessage;i++)
		{
                    int ASCIIvalue= OriginalMessage.charAt(i);
                    System.out.print("\t"+ ASCIIvalue);
                    ArrayofOriginalMessage[i]=ASCIIvalue;
		}
		System.out.print("\n");
		System.out.print("HEX-CODE:");
		for(i=0;i<lengthofMessage;i++)
		{
                    generatedString=" ";
                    b[i]=ArrayofOriginalMessage[i]%16;
                    ArrayofOriginalMessage[i]=ArrayofOriginalMessage[i]/16;
                    if(ArrayofOriginalMessage[i]==10)
                    {
			s='A';
			generatedString=generatedString+s;
                    }
                    else if(ArrayofOriginalMessage[i]==11)
                    {
			s='B';
			generatedString=generatedString+s;
                    }
                    else if(ArrayofOriginalMessage[i]==12)
                    {
                        s='C';
			generatedString=generatedString+s;
                    }
                    else if(ArrayofOriginalMessage[i]==13)
                    {
                        s='D';
			generatedString=generatedString+s;
                    }
                    else if(ArrayofOriginalMessage[i]==14)
                    {
			s='E';
			generatedString=generatedString+s;
                    }
                    else if(ArrayofOriginalMessage[i]==15)
                    {
			s='F';
                       	generatedString=generatedString+s;
                    }
                    else
                    {
                        s=(char) ArrayofOriginalMessage[i];
			generatedString=generatedString+ArrayofOriginalMessage[i];
                    }
                    //System.out.println("generated Special Character is "+generatedString +"/n");//This is done for testing
                    if(b[i]==10)
                    {
			s='A';
			generatedString=generatedString+s;
			System.out.print(generatedString.trim());
                    }
                    else if(b[i]==11)
                    {
                        s='B';
			generatedString=generatedString+s;
                	System.out.print(generatedString.trim());
                    }
                    else if(b[i]==12)
                    {
                      	s='C';
			generatedString=generatedString+s;
			System.out.print(generatedString.trim());
                    }
                    else if(b[i]==13)
                    {
                        s='D';
			generatedString=generatedString+s;
			System.out.print(generatedString.trim());
                    }
                    else if(b[i]==14)
                    {
                        s='E';
			generatedString=generatedString+s;
			System.out.print(generatedString.trim());
                    }
                    else if(b[i]==15)
                    {
                        s='F';
			generatedString=generatedString+s;
			System.out.print(generatedString.trim());						
                    }
                    else
                    {
                     	s=(char) b[i];
                      	generatedString=generatedString+b[i];
			System.out.print(generatedString.trim());
                    }
                    finalEncodedString=finalEncodedString+generatedString.trim();
                  //  System.out.println("Generated b stream"+generatedString+"\n");// This is done for testing
		}
		System.out.println("Encoded text " + finalEncodedString);
		str=finalEncodedString.getBytes();
		System.out.println("This may be a File   : " +  str);
		st=new String(str);
		digestValue(finalEncodedString.getBytes());//Here Digest Algo is applied
		keyGenerator();
		SignatureGenerator("public.txt");
                SenderSocket();
		
            }
            JOptionPane.showMessageDialog(null, "Data is send from Sender to DNS server  ","Message", JOptionPane.INFORMATION_MESSAGE);
	}
        
    }
    public void Hex_Code_Conversion(){
    
    }
    public void SenderSocket(){
        String inputValue = JOptionPane.showInputDialog("Enter the System Name for Domain1");
		try
		{
                    Socket socketofSender = new Socket(InetAddress.getByName(inputValue),9999);
                    PrintStream prtintStreamofSender = new PrintStream(socketofSender.getOutputStream());
                    prtintStreamofSender.println(ct.SenderName.getText());
                    System.out.println("SenderDomain  :"+ct.SenderName.getText());
                    prtintStreamofSender.println(ct.ReceiverName.getText());
                    System.out.println("ReceiverDomain:"+ct.ReceiverName.getText());
                    prtintStreamofSender.println(ct.SenderName.getText());
                    System.out.println("SenderName  :"+ct.SenderName.getText());
                    prtintStreamofSender.println(ct.ReceiverName.getText());
                    System.out.println("ReceiverName:"+ct.ReceiverName.getText());
                    System.out.println("File:"+ new String(str));
                    prtintStreamofSender.println(new String(str));
                    prtintStreamofSender.println("public.txt");
                    prtintStreamofSender.println("realSign.txt");
                    /*prtintStreamofSender.println("public.txt");
                    prtintStreamofSender.println("realSign.txt");
                            */
                    prtintStreamofSender.println(ct.SenderPassword.getText());
                    prtintStreamofSender.flush();
                    socketofSender.close();
                    
                }
		catch(Exception ex)
		{
                    JOptionPane.showMessageDialog(null, "Socket of Sender is not Created \nSocket might be under use ","Sender Socket", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println(ex);
		}
    }
    
    public static void main(String[] args) 
    {
        ClientDetail ObjClientDetail1 = new ClientDetail();
        SenderMessage objSenderMessage = new SenderMessage( ObjClientDetail1);
    }    
}