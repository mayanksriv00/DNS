package MajorProjectPkg;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;
import java.security.*;
import java.security.SecureRandom.*;
import java.security.spec.*;
import javax.swing.*;

public class RecieverMessage extends JFrame implements ActionListener
{
    JTabbedPane tp;
    JLabel labelSenderName,jl1,jl2,labelSenderPass;
    JButton buttonOpen,jb1,jb2;
    JTextField tf1,tf2,textFieldSenderName;
    JPasswordField textFieldSenderPass;
    JTextArea TextAreaMessage,ta1;
    JScrollPane scroll;
 
    static String y="";
    static String senderDomainName,recieverDomainName,str2,publicKey,signature , EncryptedData, sendername, recivername , senderPass;
    static String decryptedData="";
    
    public RecieverMessage()
    {
    	super("Reciever");
	String inf="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
	try
	{
            UIManager.setLookAndFeel(inf);
	}
	catch(Exception e){}
	setSize(400,450);
	Container c = getContentPane();
	JPanel panel = new JPanel();
	panel.setLayout(null);
	labelSenderName = new JLabel("Sender Name ",JLabel.LEFT);
	labelSenderPass = new JLabel("Sender Password ",JLabel.LEFT);
	textFieldSenderName = new JTextField(15);
	textFieldSenderPass = new JPasswordField(15);
	TextAreaMessage = new JTextArea(20,40);
	scroll = new JScrollPane(TextAreaMessage);
	buttonOpen= new JButton("OPEN");
	panel.add(labelSenderName);
	panel.add(textFieldSenderName);
	panel.add(labelSenderPass);
	panel.add(textFieldSenderPass);
	panel.add(scroll);
	panel.add(buttonOpen);
	labelSenderName.setBounds(25,10,150,25);
	textFieldSenderName.setBounds(150,10,150,25);
	labelSenderPass.setBounds(25,40,150,25);
	textFieldSenderPass.setBounds(150,40,150,25);
	scroll.setBounds(25,70,300,250);
	buttonOpen.setBounds(150,350,75,25);
	panel.setVisible(true);
        buttonOpen.addActionListener(this);
	tp = new JTabbedPane();
	tp.addTab("Message",null,panel,"Retrive the Message here");
	c.add(tp);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setVisible(true);
	setResizable(false);
    }

	

    public static void RecieverSocketMethod()
    {
	try
	{
            System.out.println(" Destination Server Started..... ");
            ServerSocket ss = new ServerSocket(7878);
            System.out.println(" Socket Created...... ");
            Socket s11 = ss.accept();
            BufferedReader recieverBufferData=new BufferedReader(new InputStreamReader(s11.getInputStream()));
            senderDomainName = recieverBufferData.readLine();
            senderDomainName=senderDomainName.trim();
            System.out.println("SenderDomainName   : " +senderDomainName);
            recieverDomainName = recieverBufferData.readLine();
            recieverDomainName=recieverDomainName.trim();
            System.out.println("ReceiverDomainName : " +recieverDomainName);
            sendername = recieverBufferData.readLine();
            sendername=sendername.trim();
            System.out.println("SenderName   : " +sendername);
            recivername = recieverBufferData.readLine();
            recivername=recivername.trim();
            System.out.println("ReceiverName : " +recivername);
            EncryptedData = recieverBufferData.readLine();
            EncryptedData=EncryptedData.trim();                                
            System.out.println("EncryptedData    : " +EncryptedData);
            publicKey = recieverBufferData.readLine();
            publicKey=publicKey.trim();
            System.out.println("Public Key   : " +publicKey);
            signature = recieverBufferData.readLine();
            signature=signature.trim();
            System.out.println("RealSign     : " +signature);
            senderPass = recieverBufferData.readLine();
            senderPass=senderPass.trim();   
            
            char ArrayofEncryptedData[]=new char[5000000];
            char res[]=new char[9];
            char s1[]=new char[5];
            String decryptedHexa_Code =new String();
            String r =new String();
            int i,j=0,d=1,h,n,l=8,l2=0,l1=0;
            long c=0l;
            String t,st="",st1="";
	/* Getting the Hexcode And Written into TextFile */
	    System.out.println("Encrypted Data" + EncryptedData);
                                        
            System.out.println("Enter the Hex-Code:");
            System.out.println(new String(EncryptedData));
            int len=EncryptedData.length();
            System.out.print("String Length:");
            System.out.println(len);
	    ///changed 2 ad 12  /*   Converting Hexcode into Bits    */
            for(i=0;i<len;i++)
            {
		char encryptedDataCharacters= ((EncryptedData).charAt(i));
		ArrayofEncryptedData[i]=encryptedDataCharacters;
		if(ArrayofEncryptedData[i]=='A')
		{
                    st="1010";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='B')
		{
                    st="1011";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='C')
		{
                    st="1100";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='D')
		{
                    st="1101";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='E')
		{
                    st="1110";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='F')
		{
                    st="1111";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='0')
		{
                    st="0000";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='1')
		{
                    st="0001";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='2')
		{
                    st="0010";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='3')
		{
                    st="0011";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='4')
		{
                    st="0100";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='5')
		{
                    st="0101";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='6')
		{
                    st="0110";
                    st1=st;
                }
		else if(ArrayofEncryptedData[i]=='7')
		{
                    st="0111";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='8')
		{
                    st="1000";
                    st1=st;
		}
		else if(ArrayofEncryptedData[i]=='9')
		{
                    st="1001";
                    st1=st;
		}
		decryptedHexa_Code=decryptedHexa_Code+st;
            }                                         
            char characterArrayofDecryptedHexa_Code[]=decryptedHexa_Code.toCharArray();
            String x=decryptedHexa_Code.toString();
            System.out.print("this is content " + x);
            System.out.println("\nLength:"+len);
          /*   Converting Hex into Character   */
            try
            {
		if(len==1)
		{								
                    int k;
                    k=len;							
                    for(j=k-1;j>=0;j--)
                    {
			c=c+((characterArrayofDecryptedHexa_Code[j])-48)*d;//initial values d=1,y="";
			y=y+c;
			d=d*2;											
                    }  
                    System.out.print("\nCharacter after Decreyption :");
                    decryptedData=decryptedData+(char)c;
		}
		else
		{
                    int k;
                    for(i=0;i<len;i++)
                    {
			c=0; d=1;
			k=i*8;
			for(j=k+7;j>=k;j--)
			{												
                            c=c+(characterArrayofDecryptedHexa_Code[j]-48)*d;
                            y=y+c;
                            d=d*2;												
			}
			decryptedData=decryptedData+(char)c;
			System.out.println(decryptedData);										  
                    }
		}
            }
            catch(Exception e)
            {
                //JOptionPane.showMessageDialog(null, "Exception while Converting HexaCode to Actual Code \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
		System.out.print("\ni am printing   " + e);
            }
            FileOutputStream fos=new FileOutputStream("Recv.txt");
            System.out.println(" VJ Message File Is Creacted");
            System.out.println("VJ is "+decryptedData);
            fos.write(decryptedData.getBytes());
            s11.close();		
	}       
	catch(Exception e){
            JOptionPane.showMessageDialog(null, "Exception in Decryption Algorithm \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
        }			
    }

    public static boolean verifySig(String fname) throws Exception
    {
	byte[] md;
	byte[] sign;
	byte[] realSig;
	String args=fname;
	FileInputStream fin=new FileInputStream(args);
	byte[] in_text=new byte[fin.available()];
	fin.read(in_text);
	fin.close();
	//SHA sha=new SHA(in_text);
	md=digestValue(in_text);
	FileInputStream finPublic=new FileInputStream(publicKey);
	byte[] enc_pub=new byte[finPublic.available()];
	finPublic.read(enc_pub);
	finPublic.close();
	FileInputStream sigfis=new FileInputStream(signature);
        sign=new byte[sigfis.available()];
	sigfis.read(sign);
	Signature dsa1 = Signature.getInstance("SHA1withDSA","SUN");
	X509EncodedKeySpec pubKeySpec=new X509EncodedKeySpec(enc_pub);
	KeyFactory keyFactoryPub=KeyFactory.getInstance("DSA","SUN");
	PublicKey pub=keyFactoryPub.generatePublic(pubKeySpec);
	dsa1.initVerify(pub);
	dsa1.update(md);
	boolean status=dsa1.verify(sign);
	System.out.println("Verified Signature:" + status);
	return 	status;
    }
    private static byte[] content;
    public static byte[] digestValue(byte[] in_text1)
    {
	byte[] in_text=in_text1;
	content=in_text;
	MessageDigest mg1=null;
	try
	{
            mg1=MessageDigest.getInstance("SHA1");
	}
	catch (Exception e)
	{
            System.out.println(e);
	}
	mg1.update(content);
	byte[] digest1=mg1.digest();
	System.out.println("Message Digest:"+digest1);
	return digest1;
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == buttonOpen)
	{
            System.out.println("Buttion is clicked");
            if(((textFieldSenderName.getText()).equals(sendername)) && ((textFieldSenderPass.getText()).equals(senderPass)))
            {
                System.out.println("Verify Signature are Generated");
                try
                {
                    System.out.println("Verifyngfhfhh Signature are Generated");
                    boolean b=  verifySig(publicKey);
                    if(b)
                    {
                    JOptionPane.showMessageDialog(null, "Signature are Verified","Verify Sign", JOptionPane.INFORMATION_MESSAGE);
                    JOptionPane.showMessageDialog(null,"Receiver accept the data from Domain2","Receiver",JOptionPane.INFORMATION_MESSAGE);
                    TextAreaMessage.setText(decryptedData);
                    }
                    else
                    JOptionPane.showMessageDialog(null, "Signature aredhfdshfsfuhdsfhd Verified","Verify Sign", JOptionPane.INFORMATION_MESSAGE);   
                }
                catch(Exception e1)
                {
                    System.out.println(e1);
                }
            }
            else
                JOptionPane.showMessageDialog(null, "Sender Name or Sender Password  is Incorrect","Alert", JOptionPane.ERROR_MESSAGE);            
	}
    }
    public static void main(String arg[])throws Exception
    {
	RecieverMessage rm = new RecieverMessage();
	rm.RecieverSocketMethod();
    }
}
