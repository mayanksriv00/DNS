package MajorProjectPkg;                                                                                                                                                                                                import java.io.*;
import java.net.*; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DnsServer implements ActionListener

{
    static String senderDomainName,recieverDomainName,senderName,recieverName,encryptedData,publicKey,signature,senderPass;
    static JFrame frameName;
    static JTextField textFieldSenderName,textFieldRevieverName;
    static JLabel MainHeadingName,labelSenderName,labelSenderPassword,labelRecieverName;
    static JPasswordField textFieldSenderPassword;
    static JTextArea testArea;
    static JScrollPane scroll;
    static JButton Send,Exit;
    static JPanel panel;
  
    DnsServer()
    {
	String inf="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
	try
	{
            UIManager.setLookAndFeel(inf);
	}
	catch(Exception e){}
	frameName =new JFrame("DNSServer");
	MainHeadingName = new JLabel("DNS-Server Contains the Domains");
	labelSenderName = new JLabel("SenderName			:");
        labelSenderPassword = new JLabel("Sender Password			:");
	labelRecieverName = new JLabel("ReceiverName		:");	
	textFieldSenderName = new JTextField(20);
	textFieldSenderPassword = new JPasswordField(20);
	textFieldRevieverName = new JTextField(20);
	testArea = new JTextArea();
	scroll = new JScrollPane(testArea);
	Send= new JButton("Send");
	Exit= new JButton("Exit");
	Font f = new Font("Bold Italic",Font.PLAIN,20);
	MainHeadingName.setFont(f);
	panel = new JPanel();
	panel.add(MainHeadingName);
	panel.add(labelSenderName);
	panel.add(labelSenderPassword);
	panel.add(labelRecieverName);
	panel.add(textFieldSenderName);
	panel.add(textFieldSenderPassword);
	panel.add(textFieldRevieverName);
	panel.add(scroll);
	panel.add(Send);
	panel.add(Exit);
	Send.addActionListener(this);
	Exit.addActionListener(this);
	panel.setLayout(null);
	MainHeadingName.setBounds(40,40,350,25);
	labelSenderName.setBounds(40,80,120,25);
	textFieldSenderName.setBounds(180,80,120,25);
	labelSenderPassword.setBounds(40,110,120,25);
	textFieldSenderPassword.setBounds(180,110,120,25);
	labelRecieverName.setBounds(40,140,120,25);
	textFieldRevieverName.setBounds(180,140,120,25);
	scroll.setBounds(40,170,300,180);
	Send.setBounds(100,370,75,25);
	Exit.setBounds(200,370,75,25);
	frameName.setContentPane(panel);
	frameName.setSize(400,470);
	frameName.setVisible(true);
        frameName.setResizable(false);
    }

    public void actionPerformed(ActionEvent e12)
    {
	if(e12.getSource()==Send)
	{
            if(((textFieldRevieverName.getText()).equals(recieverName)) && ((textFieldSenderName.getText()).equals(senderName)) && ((textFieldSenderPassword.getText()).equals(senderPass)))
            {
                Soc1();
                JOptionPane.showMessageDialog(null, "Data is sent to Reciever ","Message", JOptionPane.INFORMATION_MESSAGE);
            }
            else
                JOptionPane.showMessageDialog(null, "Sender Name or Sender Password or Reciver Name is Incorrect","Alert", JOptionPane.ERROR_MESSAGE);
	}
	else
	{
            System.out.println("Connection Refused");
	}
	if(Exit== e12.getSource())
	{
        	System.exit(0);
	}
    }

    public static void ServSoc1()
    {
	try
	{
            ServerSocket senderSocket = new ServerSocket(9999);
            Socket s1 = senderSocket.accept();
            BufferedReader senderDataReader=new BufferedReader(new InputStreamReader(s1.getInputStream()));
            senderDomainName = senderDataReader.readLine();
            senderDomainName=senderDomainName.trim();
            System.out.println("SenderDomain  :"+senderDomainName);
            recieverDomainName = senderDataReader.readLine();
            recieverDomainName=recieverDomainName.trim();
            System.out.println("ReceiverDomain:"+recieverDomainName);
            senderName = senderDataReader.readLine();
            senderName=senderName.trim();
            System.out.println("SenderName    :"+senderName);   
            recieverName = senderDataReader.readLine();
            recieverName=recieverName.trim();
            System.out.println("ReceiverName  :"+recieverName);
            encryptedData = senderDataReader.readLine();
            encryptedData=encryptedData.trim();
            System.out.println("EncryptedData :"+encryptedData);
            try
            {                
		testArea.setText("EncryptedData :"+encryptedData+"\n");
            }
            catch(Exception e)
            {
		e.printStackTrace();
            }
            publicKey = senderDataReader.readLine();
            //String sstr = str71;
            publicKey=publicKey.trim();
            System.out.println("Public Key    :"+publicKey);
            //str72 = sstr;
            signature = senderDataReader.readLine();
            signature=signature.trim();
            System.out.println("Signature     :"+signature);
            senderPass = senderDataReader.readLine();
            senderPass=senderPass.trim();
            System.out.println("SenderPassword    :"+senderPass);
            System.out.println("Server Checking the List of Domains");
            System.out.println("Now Checking wih Domain1");
            System.out.println("Now Checking wih Domain2");
            s1.close();
	}
	catch(Exception e)
	{
            JOptionPane.showMessageDialog(null, "Exception while retrieving data of Sender \n Exception is: "+ e,"Exception", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(e);
	}
    }

    public static void Soc1()
    {
	try
	{
            System.out.println("I am inside try");			
            String inputValue = JOptionPane.showInputDialog("Enter the System Name for Domain2");
            Socket recieverSocket = new Socket(InetAddress.getByName(inputValue),7878);
            System.out.println("Socket Created");
            PrintStream printStreamofReciever = new PrintStream(recieverSocket.getOutputStream());
            System.out.println("senderDomainName " + senderDomainName);
            System.out.println("recieverDomainName " + recieverDomainName);
            System.out.println("senderName " + senderName);
            System.out.println("recieverName " + recieverName);
            System.out.println("encryptedData " + encryptedData);
            System.out.println("publicKey " + publicKey);
            System.out.println("signature " + signature);
            printStreamofReciever.println(senderDomainName);
            printStreamofReciever.println(recieverDomainName);
            printStreamofReciever.println(senderName);
            printStreamofReciever.println(recieverName);
            printStreamofReciever.println(encryptedData);
            printStreamofReciever.println(publicKey);
            printStreamofReciever.println(signature);
            printStreamofReciever.println(senderPass);
            printStreamofReciever.flush();
            System.out.println("Data Has Been written");
            recieverSocket.close();
	}
	catch(Exception e)
	{
            JOptionPane.showMessageDialog(null, "Socket of Reciever not Created"," Reciever Socket", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("i am printing " + e);
	}
    }
        
    public static void main(String args[]) throws Exception
    {
	DnsServer DS = new DnsServer();
	DS.ServSoc1();
    }
}

